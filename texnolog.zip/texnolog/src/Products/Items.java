package Products;

public class Items {
    private String characteristic;
    private int cost;
    private int quantity;
    public String getCharacteristic () {
        return characteristic;
    }
    public int getCost() {
        return cost;
    }
    public int getQuantity() {
        return quantity;
    }
    public Items(String characteristic,int cost,int quantity){
        this.characteristic=characteristic;
        this.cost=cost;
        this.quantity=quantity;
    }
    public void reduceQuantity(){
         this.quantity=this.quantity - 1;
    }
}
