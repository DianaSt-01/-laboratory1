package Products;

import Products.Items;

import java.util.ArrayList;

public class Orders {
    public static ArrayList<Items> getOrder(){
        ArrayList<Items> items=new ArrayList<Items>();
        return items;
    }
}
