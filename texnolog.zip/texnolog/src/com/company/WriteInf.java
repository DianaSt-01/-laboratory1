package com.company;

import Products.Items;

import java.util.ArrayList;

public class WriteInf {
    public static void writeCheck(int sum, ArrayList<Items> list){

    }
}
