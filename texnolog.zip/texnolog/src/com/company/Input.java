package com.company;

import java.util.Scanner;

public class Input {
    public static String input_user() {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        return input;
    }
}
