package Users;

import Products.AllItems;
import Products.Items;
import Products.Orders;
import com.company.*;

import java.util.ArrayList;

public class ShopAssistent extends User implements IUser {
    public ShopAssistent(String login, String password){

        super(login,password);

    }
    public void Watch(){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items){
            String s="Название продукта"+ item.getCharacteristic()+"Цена продукта"+ item.getCost() + "Количество товара" + item.getQuantity();
            Otput.outputText(s);
        }
    }
    public void Order(){
ArrayList<Items> list= Orders.getOrder();
int sum=0;
for(Items item: list){
    item.reduceQuantity();
    sum=sum + item.getCost();
}
WriteInf.writeCheck(sum, list);
    }

}
