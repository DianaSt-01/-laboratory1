package Users;
import Products.AllItems;
import com.company.Input;
import Products.Items;
import com.company.Otput;

import java.util.ArrayList;

public class Customer extends User implements IUser {
    public Customer(String login, String password){
        super(login,password);

    }
    public void Order(Items items) {
Otput.outputText("Введите название необходимого товара");
String NeedItem= Input.input_user();
Items item= AllItems.findItems(NeedItem);
String s="Цена товара" + item.getCost();
Otput.outputText(s);
    }
    public void Watch(){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items){
            String s="Название продукта"+ item.getCharacteristic()+"Цена продукта"+ item.getCost();
            Otput.outputText(s);
        }
    }

}
