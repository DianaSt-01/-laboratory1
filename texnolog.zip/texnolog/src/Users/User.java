package Users;

import Products.AllItems;
import com.company.Input;
import Products.Items;
import com.company.Otput;

import java.util.ArrayList;

public abstract class User implements IUser {

    private String login;
    private String password;
    public String getLogin () {
        return login;
    }
    public String getPassword () {
        return password;
    }
    public User (String login,String password){
       this.login=login;
       this.password=password;
    }
    public void Watch(){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items){
            String s="Название продукта"+ item.getCharacteristic()+"Цена продукта"+ item.getCost() ;
            Otput.outputText(s);
        }
    }
    public void Order(){
        ArrayList<Items> Orders = new ArrayList<Items>();
        int k=0;
        do {
            Otput.outputText("Введите название продукта");
            String name = Input.input_user();
            Items item = findItem(name);
            Orders.add(item);
            Otput.outputText("ЕСли хотите выйти, нажмите 4");
            k=Integer.parseInt(Input.input_user());

        } while(k!=4);
    }
    public Items findItem(String name){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items ){
            if(item.getCharacteristic().equals(name)){
                return item;
            }
        }
        return null;
    }

}
