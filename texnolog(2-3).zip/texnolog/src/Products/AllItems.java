package Products;

import java.util.ArrayList;

public class AllItems {
    public static ArrayList<Items> getItems(){
        ArrayList<Items> list = new ArrayList<Items>();
        list.add(new Items("Колбаса", 18,3));
        list.add(new Items("Соль", 20,1));
        list.add(new Items("Сахар", 8,2));
        list.add(new Items("Молоко", 6,8));
        list.add(new Items("Овсянка", 12,5));
        return list;
    }
    public static Items findItems(String name){
        ArrayList<Items> list = getItems();
        for(Items s: list){
            if(s.getCharacteristic()==name.trim())
            {
                return s;
            }
        }
        return new Items("",0,0);
    }
}
