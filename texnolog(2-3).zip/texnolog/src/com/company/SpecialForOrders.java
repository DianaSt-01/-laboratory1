package com.company;

import Products.Items;

import java.util.HashMap;
import java.util.Map;
import Users.*;
public class SpecialForOrders {

   public  synchronized void OrderCustomer(){
       Otput.outputText("ПОКУПАТЕЛЬ");

       HashMap<Items, Integer> list= ForOrders.Deserialize();
       while (list.size()==1) {
           try {
               wait();
           }
           catch (InterruptedException e) {
           }
       }
       HashMap<Items,Integer> map= new HashMap<Items,Integer>();
       int k=0;
       do {
           Otput.outputText("Введите название продукта");
           String name = Input.input_user();
           Items item = User.findItem(name);
           Otput.outputText("Введите количество товара");
           int t=Integer.parseInt(Input.input_user());
           map.put(item,t);
           Otput.outputText("ЕСли хотите выйти, нажмите 4");
           try{
               k=Integer.parseInt(Input.input_user());
           }
           catch(RuntimeException ex){
               Otput.outputText("Вы ввели не число");

           }
           //  k=Integer.parseInt(Input.input_user());

       } while(k!=4);


       ForOrders.Serialize(map);
       HashMap<Items, Integer> list1= ForOrders.Deserialize();

       Otput.outputText("Размер" + String.valueOf(list1.size()));
       notify();

   }
   public synchronized   void OrderAssistant(){
       Otput.outputText("ПРОДАВЕЦ");
       HashMap<Items, Integer> list= ForOrders.Deserialize();
       while (list.size()!=1) {
           try {
               wait();
           }
           catch (InterruptedException e) {
           }
       }
       int sum=0;
       for (Map.Entry<Items, Integer> h : list.entrySet()) {
           sum= sum + h.getValue();

       }
       WriteInf.writeCheck(sum, list);
       ForOrders.Serialize(new HashMap<Items,Integer>());
notify();
   }
}
