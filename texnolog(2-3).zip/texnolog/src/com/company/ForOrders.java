package com.company;
import java.io.*;
import Products.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ForOrders {
    public static void Serialize(HashMap<Items, Integer> map){
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("E:\\Univer\\5_sem\\texnolog\\text1.txt")))
        {
            oos.writeObject(map);

        }
        catch(Exception ex){

            System.out.println(ex.getMessage());
        }

    }
    public static HashMap<Items, Integer> Deserialize() {
        HashMap<Items, Integer> items = new HashMap<Items, Integer>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("E:\\Univer\\5_sem\\texnolog\\text1.txt"))) {

            items = ((HashMap<Items, Integer>) ois.readObject());
        } catch (Exception ex) {

            System.out.println(ex.getMessage());
        }
        return items;
    }
}
