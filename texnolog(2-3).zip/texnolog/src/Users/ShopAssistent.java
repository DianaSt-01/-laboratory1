package Users;

import Products.AllItems;
import Products.Items;
import com.company.*;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

public class ShopAssistent extends User   {
   /* public ShopAssistent(String login, String password){

        super(login,password);

    }*/
   public ShopAssistent(SpecialForOrders o) {

       super(o);
   }
    public void Watch(){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items){
            String s="Название продукта"+ item.getCharacteristic()+"Цена продукта"+ item.getCost() + "Количество товара" + item.getQuantity();
            Otput.outputText(s);
        }
    }

    public  synchronized void Order(){

       /* Otput.outputText("ПРОДАВЕЦ");
        HashMap<Items, Integer> list= ForOrders.Deserialize();
        while (list.size()!=1) {
            try {
                wait();
            }
            catch (InterruptedException e) {
            }
        }
        int sum=0;
        for (Map.Entry<Items, Integer> h : list.entrySet()) {
            sum= sum + h.getValue();

        }
        WriteInf.writeCheck(sum, list);
        ForOrders.Serialize(new HashMap<Items,Integer>());
        notify();*/getO().OrderAssistant();

    }

}
