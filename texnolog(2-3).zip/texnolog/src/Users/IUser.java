package Users;

public interface IUser {
    public void Order();
  ///  public void Reverse();
    public void  Watch();
}
