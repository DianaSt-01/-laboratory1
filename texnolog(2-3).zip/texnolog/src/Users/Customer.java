package Users;
import com.company.ForOrders;
import com.company.Input;
import com.company.Otput;

import java.util.ArrayList;
import java.util.HashMap;

import Products.*;
import com.company.SpecialForOrders;

public class Customer extends User  {
 /*   public Customer(String login, String password){
        super(login,password);

    }*/
 public Customer(SpecialForOrders o) {

     super(o);
 }
    public  void Order(){

       /* Otput.outputText("ПОКУПАТЕЛЬ");

        HashMap<Items, Integer> list= ForOrders.Deserialize();
        while (list.size()==1) {
            try {
                wait();
            }
            catch (InterruptedException e) {
            }
        }
        HashMap<Items,Integer> map= new HashMap<Items,Integer>();
        int k=0;
        do {
            Otput.outputText("Введите название продукта");
            String name = Input.input_user();
            Items item = findItem(name);
            Otput.outputText("Введите количество товара");
            int t=Integer.parseInt(Input.input_user());
            map.put(item,t);
            Otput.outputText("ЕСли хотите выйти, нажмите 4");
            try{
                k=Integer.parseInt(Input.input_user());
            }
            catch(RuntimeException ex){
Otput.outputText("Вы ввели не число");

            }
          //  k=Integer.parseInt(Input.input_user());

        } while(k!=4);


        ForOrders.Serialize(map);
        HashMap<Items, Integer> list1= ForOrders.Deserialize();

        Otput.outputText("Размер" + String.valueOf(list1.size()));
notify();*/
getO().OrderCustomer();
    }
    public void Watch(){

        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items){
            String s="Название продукта"+ item.getCharacteristic()+"Цена продукта"+ item.getCost();
            Otput.outputText(s);
        }
    }

}
