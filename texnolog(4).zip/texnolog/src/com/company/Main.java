package com.company;
import Users.*;
public class Main {

    public static void main(String[] args) {
	// write your code here
        SpecialForOrders o=new SpecialForOrders();
        ShopAssistent assistent = new ShopAssistent(o);
       Customer cunstomer = new Customer(o);


           new Thread(cunstomer).start();
           new Thread(assistent).start();

    }
}
