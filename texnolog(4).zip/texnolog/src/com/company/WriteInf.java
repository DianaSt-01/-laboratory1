package com.company;

import Products.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class WriteInf {
    public static void writeCheck(int sum, HashMap<Items, Integer> list){
        for (Map.Entry<Items, Integer> h : list.entrySet()) {
            Otput.outputText(h.getKey().getCharacteristic());

        }
Otput.outputText("Всего:"+ sum );
    }
}

