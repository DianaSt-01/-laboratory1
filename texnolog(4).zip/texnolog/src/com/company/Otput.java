package com.company;

public class Otput {
    public static void  outputText(String text) {
        System.out.println(text);
        System.out.println("                    ");
    }
}
