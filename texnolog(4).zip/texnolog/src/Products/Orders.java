package Products;

import Products.Items;

import java.util.ArrayList;

public class Orders {
    public ArrayList<Items> getOrder(){
        return items;
    }
    private ArrayList<Items> items;
    public Orders(ArrayList<Items> items){
        this.items=items;
    }


}
