package Users;

import Products.AllItems;
import com.company.Input;
import Products.Items;
import com.company.Otput;
import com.company.SpecialForOrders;

import java.util.ArrayList;

public abstract class User implements IUser, Runnable{

    /*private String login;
    private String password;
    public String getLogin () {
        return login;
    }
    public String getPassword () {
        return password;
    }
    public User (String login,String password){
       this.login=login;
       this.password=password;
    }*/
private SpecialForOrders o;
public User(SpecialForOrders o){

    this.o=o;
}
public SpecialForOrders getO(){
    return this.o;
}
    public void run(){

        Order();
    }
    public static Items findItem(String name){
        ArrayList<Items> items= AllItems.getItems();
        for(Items item: items ){
            if(item.getCharacteristic().equals(name)){
                return item;
            }
        }
        return null;
    }

}
